package cg;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

class ValidatorTest {

	
	@ParameterizedTest
	@ValueSource(strings= {"racecar","radar","nitin","naman"}) //when we have to paas single value at a time
	void Test3(String data)
	{
		Validator ob=new Validator();
		System.out.println("Test Palindrome with Data"+data);
		assertTrue(ob.isPalindrome(data));
	}
	
	@ParameterizedTest
	@CsvSource({"4,5","10,20","100,500"})  //when we have to paas multiple Values
	//conversion from String is converted into int 
	void test4(int a,int b)
	{
		Calculator ob =new Calculator();
		System.out.println("test add with value a="+a+","+b);
		assertTrue(ob.add(a, b)>0);
	}
	
	@ParameterizedTest
	@MethodSource("testaddwithoutput")    //Helpful for assert Equal
	void withMethodSource(int a,int b,int op)
	{
		Calculator ob=new Calculator();
		System.out.println("test with add input a= "+a+",b= "+b+",output"+op);
		assertEquals(op, ob.add(a, b));
	}
		
	private static Stream<Arguments> testaddwithoutput(){
		return Stream.of(
				Arguments.of(4,5,9),
				Arguments.of(100,500,600));
	}
	@Test
	void Test1()
	{
		String data="100";
		Validator ob =new Validator();
		assertTrue(ob.ValidateNo(data)); //Result positive when we pass String only  i.e. not null
		// assertTrue(ob.ValidateNo(10));  //we can not pass int because we defind the method as String
		// assertFalse(ob.ValidateNo("abc"));  directly or by initializing the data
		System.out.println("Assert True");
		Assumptions.assumeFalse(data==null); //check the condition first if true then false true combination so next statements are skipped
		System.out.println("Assert False");
		Assumptions.assumeTrue(data==null);  //check the condition first if false then false true combination so next statements are skipped and if condition true then true true next statements are executed
		System.out.println("Anything");
		data="abc";
		assertFalse(ob.ValidateNo("abc"));
	}
		
	@Test
	void Test2()
	{
		Validator ob =new Validator();
		// assertTrue(ob.ValidateNo(null));
		assertThrows(NullPointerException.class, ()->ob.ValidateNo(null));
		/*
		 * ()-> this is lamda
		 * and internally it will create one class
		 * 
		 * class ____________ implements Executable
		 * {
		 * 		public boolean execute()  //() here will indicates this () brackates are validated internally
		 * 		{
		 * 			return ob.validateNo(null);
		 *		} 	
		 * }
		 * 
		 */
	}
		

}
