package cg;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

public class Validator {
	

	public int getSizeinMl(Size size)
	{
		return size.getMl();
	}

	public boolean validateNo(String data)
	{
		return data.matches("\\d+");
	}
	
	@ParameterizedTest
	@EnumSource(Size.class)
	void withAllEnumValues(Size size)
	{
		System.out.println("Test for Enum Values "+size);
		Validator ob=new Validator();
		assertEquals(size.getMl(),ob.getSizeinMl(size));
	}
	
	
	public boolean ValidateNo(String data)
	{
		
		return data.matches("\\d+");  //+ means one or more digit
	}
	
	public boolean isPalindrome(String data)
	{
		StringBuffer sb=new StringBuffer(data);
		String reverseS=sb.reverse().toString();
		
		return data.equals(reverseS);
	}

}
