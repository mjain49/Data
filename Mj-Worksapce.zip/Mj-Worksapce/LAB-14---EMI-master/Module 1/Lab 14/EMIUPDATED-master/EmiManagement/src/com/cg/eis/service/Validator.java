package com.cg.eis.service;

public interface Validator {
	String empIdpattern="[1-9][0-9][0-9]";
	String empNamepattern = "[A-Za-z]{3}([A-Za-z])*( [A-Za-z]{3}([A-Za-z])*)* [A-Za-z]{3}([A-Za-z])*";
	String empDesgpattern="clerk|system associate|programmer|manager";
	
	
	public static boolean validatedata(String data, String pattern)
	{
		return data.matches(pattern);
	}

}