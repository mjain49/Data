package com.cg.service;

public class Exercise4 {

	private int id;
	private String name;
	private String desg;

	public Exercise4(int id, String name, String desg) {
		super();
		this.id = id;
		this.name = name;
		this.desg = desg;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesg() {
		return desg;
	}

	public void setDesg(String desg) {
		this.desg = desg;
	}

	public void displayDetails(Exercise4 emp) {
		System.out.println("Emp ID : " + emp.getId());
		System.out.println("Emp Name : " + emp.getName());
		System.out.println("Emp Designation : " + emp.getDesg());
	}

	// interface

	interface MyInterface<T> {
		public void display(T o);
	}

	public static void main(String[] args) {

		Exercise4 exe = new Exercise4(101, "Bob", "Manager");

		MyInterface<Exercise4> ob = exe::displayDetails;

		ob.display(exe);
	}
}
