package com.cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;

import javax.xml.ws.Service;

public class Exercise6 {
	public static void main(String args[]) {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        try{
            System.out.println("Enter day(1-31)");
            int day = Integer.parseInt(br.readLine());
            
            System.out.println("Enter month(1-12)");
            int month = Integer.parseInt(br.readLine());
            
            System.out.println("Enter year");
            int year = Integer.parseInt(br.readLine());
            
            Date date = new Date(year-1900, month, day);
            
            System.out.println(date);
            
            printDuration(date);
            
        }catch(IOException e){
            System.out.println("Wrong input given");
        }
	}

public static void printDuration(Date user_date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(user_date);
        
        LocalDate given_date = LocalDate.of(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        
        LocalDate sys_date = LocalDate.now();
        
        Period diff = Period.between(sys_date, given_date);
        
        System.out.println("Duration in days : "+Math.abs(diff.getDays()));
        System.out.println("Duration in months : "+Math.abs(diff.getMonths()));
        System.out.println("Duration in years : "+Math.abs(diff.getYears()));
    }
}
