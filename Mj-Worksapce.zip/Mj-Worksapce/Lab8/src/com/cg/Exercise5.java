package com.cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class Exercise5 {

	public static void main(String args[])
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try 
		{
			String s=br.readLine().trim();
			 System.out.println(CheckString(s) ? "String is positive string" : "String is not positive string");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	public static boolean CheckString(String input){
	        input = input.toLowerCase();
	        char prev_char = input.charAt(0);
	        for(int i=1;i<input.length();i++){
	            char next_char = input.charAt(i);
	            if((int)prev_char > (int)next_char) //ASCII value is compared
	            	return false;
	        }
	        return true;
	    }
}
