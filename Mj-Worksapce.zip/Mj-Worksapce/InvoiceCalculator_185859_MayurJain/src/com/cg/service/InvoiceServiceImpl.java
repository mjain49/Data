package com.cg.service;
import java.util.Map;
import com.cg.bean.Invoice;
import com.cg.dao.InvoiceRepoImpl;

public class InvoiceServiceImpl implements InvoiceService{

 //Declaring Percentages for tax

 final double CGST=3.5;

 final double SGST=3.5;

 InvoiceRepoImpl inDaoRepo=new InvoiceRepoImpl(); //for saving and retrieving from database
 
 @Override
 public double calculateInvoice(Invoice ob) {

 int weight=ob.getWeight();
 int distance=ob.getDistance();
 
 //charge is Rs. 2 per km into weight
 double transport_charges=2*distance*weight; 
 //cgst on transport charge
 double cgst=CGST*transport_charges/100; 
 //sgst  on transport charge
 double sgst=SGST*transport_charges/100; 
 ob.setCgst(cgst);
 ob.setSgst(sgst);
 
 double total_amount=transport_charges+cgst+sgst;
 ob.setAmount(total_amount);
 
 return total_amount;
 }
 
 
 public Map<Integer, Invoice> getAllInvoices() 
 {
 return inDaoRepo.getAllInvoices();
 }

 public int saveInvoice(Invoice ob) 
 {
 calculateInvoice(ob);
 return inDaoRepo.saveInvoice(ob);
 }
}