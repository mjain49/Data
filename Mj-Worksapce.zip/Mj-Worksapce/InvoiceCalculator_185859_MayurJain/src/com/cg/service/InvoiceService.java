package com.cg.service;

import java.util.Map;

import com.cg.bean.Invoice;

public interface InvoiceService {

	//For Calculating the total amount
	double calculateInvoice(Invoice ob);
	
	//For displaying all the invoices
	Map<Integer,Invoice> getAllInvoices();
	
	//saving all data into collection
	int saveInvoice(Invoice ob);

}
