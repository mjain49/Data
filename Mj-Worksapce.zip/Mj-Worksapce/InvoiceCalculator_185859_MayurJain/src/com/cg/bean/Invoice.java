package com.cg.bean;

import java.util.Random;

public class Invoice {

	//Required Annotations 
	private int id;
	private int weight;
	private int distance;
	private double amount;
	private double cgst;
	private double sgst;
	
	

	 public Invoice(int weight, int distance) {
	 super();
	 this.id=idgenerator(); //Random Id Generator between 0 and 1000
	 this.weight = weight;
	 this.distance = distance;
	 }
	 
	//Getters and Setters for the above annotations
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getCgst() {
		return cgst;
	}
	public void setCgst(double cgst) {
		this.cgst = cgst;
	}
	public double getSgst() {
		return sgst;
	}
	public void setSgst(double sgst) {
		this.sgst = sgst;
	}
	
	//To String Implementation
	@Override
	public String toString() {
		return "Invoice [id=" + id + ", weight=" + weight + ", distance=" + distance + ", amount=" + amount + ", cgst="
				+ cgst + ", sgst=" + sgst + "]";
	}
	
	
	public static int idgenerator() {
		 Random rnd = new Random();
		 int id=rnd.nextInt(1000);
		 return id;
		 }
}
