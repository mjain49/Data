package com.cg.dao;

import java.util.Map;

import com.cg.bean.Invoice;

public interface InvoiceRepo {
	int saveInvoice(Invoice ob);
	public Map<Integer,Invoice> getAllInvoices();
}
