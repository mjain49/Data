package com.cg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Exercise3 {
	
	public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        try{
            System.out.println("Enter file path");
            String path = br.readLine();
            
            
            System.out.println(getFileinfo(path));
        }catch(IOException e){
            System.out.println("Wrong input is given");
        }
    }
	
	public static String getFileinfo(String path){
        try{
            File file = new File(path);
            BufferedReader br = new BufferedReader(new FileReader(file));
            
            if(file.exists()){
                String line = null;
                int character_count = 0;
                int line_count = 0;
                int word_count = 0;
                while((line = br.readLine())!=null){
                    line = line.replaceAll(" +"," ").trim();
                    StringTokenizer token = new StringTokenizer(line," ");
                    while(token.hasMoreTokens()){
                        word_count++;
                        token.nextToken();
                    }
                    line = line.replaceAll(" +","");
                    character_count += line.length();
                    line_count++;
                }
                return "Character count : "+character_count+
                        "\nLine count : "+line_count+
                        "\nWord count : "+word_count;
            }else{
                System.out.println("File does not exist");
            }
            
        }catch(IOException e){
            System.out.println("Error in reading file");
        }
        return null;
    }
}
