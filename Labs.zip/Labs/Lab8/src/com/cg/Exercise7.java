package com.cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise7 {
	public static void main(String args[]) {
	        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	       
	        try{
	            System.out.println("Enter username of jobseeker");
	            String username = br.readLine();
	            System.out.println(validatename(username)?"User name is valid":"Username is invalid");
	        }catch(IOException e){
	            System.out.println("Wrong input given");
	        }       
	    }		
	public static boolean validatename(String username){
        if(username.matches("\\w{8}(\\w)*_job"))
        	return true;
        return false;
    }
}
