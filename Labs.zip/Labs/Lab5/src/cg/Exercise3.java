package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Exercise3 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Any Number");
		int n=sc.nextInt();
		//int i=3,s,j=3;
		if(n>1)
		{
			System.out.println("The Prime Numbers are");
			for(int i=2;i<=n;i++)
			{
				int p=0;
				for(int j=1;j<=i;j++)
				{
					if(i%j==0)
						p++;
				}
				if(p==2)
				{
					System.out.print("\t"+i);
				}
			}
			
		}
		else
		{
			System.out.println("No Prime Positive Number before "+n);
		}
	}
}
