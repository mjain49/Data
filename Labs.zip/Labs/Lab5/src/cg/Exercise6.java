package cg;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Exercise6 {
	public static void main(String args[]) throws EmployeeException
	{
		try
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Salary of Employee :");
		double a=sc.nextDouble();
		if(a>3000.00)
		{
			System.out.println("Valid Age");
		}
		else
		{
			throw new EmployeeException();
		}
		}
		catch(InputMismatchException e)
		{
			e.getStackTrace();
		}
	}

}