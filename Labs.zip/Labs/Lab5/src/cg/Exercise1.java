package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise1 {
 
	public static void main(String args[]) throws IOException
	{
		BufferedReader br=new BufferedReader( new InputStreamReader(System.in));
		System.out.println("1.Red Light");
		System.out.println("2.Yellow Light");
		System.out.println("3.Green Light");
		String c=br.readLine();
		
		switch(c)
		{
		case "1":System.out.println("STOP");
				break;
		case "2":System.out.println("READY");
				break;
		case "3":System.out.println("GO");
				break;
		default:System.exit(0);//Wrong Choice
		}
		
	}
}
