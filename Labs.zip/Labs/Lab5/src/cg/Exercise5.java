package cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercise5 {
	public static void main(String args[]) throws UserDefinedException1
	{
		try
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Age :");
		int a=sc.nextInt();
		if(a>15)
		{
			System.out.println("Valid Age");
		}
		else
		{
			throw new UserDefinedException1();
		}
		}
		catch(InputMismatchException e)
		{
			e.getStackTrace();
		}
	}

}

class UserDefinedException1 extends Exception
{
	UserDefinedException1()
	{
		System.out.println("Invalid");
	}
}