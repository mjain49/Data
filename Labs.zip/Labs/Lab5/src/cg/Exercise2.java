package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Exercise2 {

	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Number of elements in the series:");
		int n=sc.nextInt();
		int a[]=new int[n];
		int r=0;
		r=recursive(n);
		if(n>=2)
		{
			a[0]=1;
			a[1]=1;
			for(int i=2;i<n;i++)
			{
				a[i]=nonrecursive(a[i-1],a[i-2]);
			}
			System.out.println("N th Element of Fibonaaci Series(USING RECURSIVE FUNCTION)="+r);
			System.out.println("N th Element of Fibonaaci Series(USING NON RECURSIVE FUNCTION)= "+a[n-1]);
		}
		else if(n==1||n==2)
		{
			n=1;
			System.out.println("N th Element of Fibonaaci Series="+n);
		}
		else
			System.out.println("Enter valid Choice");
	}
	
	
	private static int recursive(int n) {
		// TODO Auto-generated method stub
		if(n==1||n==2)
			return 1;
		else
		return recursive(n-1)+recursive(n-2);
	}

	public static int nonrecursive(int i, int j) {
		int r=0;
		return r=i+j;
	}
	
}
