package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise4 {
	public static void main(String args[]) throws IOException, UserDefinedException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Full Name Of Employee:");
		String fn=br.readLine().trim();
		String ln;
		try {
		String[] parts=fn.split(" ");
		fn=parts[0];
		ln=parts[1];
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			throw new UserDefinedException();
		}
		if(fn.length()==0||ln.length()==0)
		{
			throw new UserDefinedException();
		}
		else
		{
			System.out.println("Valid Name");
		}
	}
}

class UserDefinedException extends Exception
{
	UserDefinedException()
	{
		System.out.println("Invalid");
	}
}
