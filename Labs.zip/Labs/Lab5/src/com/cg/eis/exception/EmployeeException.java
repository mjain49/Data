package com.cg.eis.exception;

import java.util.Arrays;

public class EmployeeException extends Exception{

	public EmployeeException() {
		
	}
	
	public EmployeeException(String msg) {
		super(msg);
	}
	
	public String toString() {
		return "EmployeeException:"+super.getMessage();
	}

	
}
