package com.cg.service;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise1 {
	
	interface MyInterface {

		// Functional Interface

		public double fun(long a, long b);
	}

	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try {
			// Taking two numbers as input from user
			System.out.println("Enter first number: ");
			long a = Long.parseLong(br.readLine());

			System.out.println("Enter second number: ");
			long b = Long.parseLong(br.readLine());

			// Implementing lambda expression to calculate x to the power y

			MyInterface ob = (x, y) -> Math.pow(a, b);
			// using build-in pow function of Math

			System.out.println("Result = " + ob.fun(a, b));

		} catch (IOException e) {
			System.out.println("Wrong input given ");
		}
	}
}
