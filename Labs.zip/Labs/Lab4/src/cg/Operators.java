package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/*
 * @Author:Mj_49
 */
public class Operators {
	
	public static void main(String args[]) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		double result,n;
		System.out.println("Enter the N digit number");
		n=Integer.parseInt(br.readLine());
		if(n>0)
		{
			result=sumOfCube(n);
			System.out.println("Result="+result);
		}
		else
			System.out.println("Invalid Input please enter Positive Number");
		
	}
	private static double sumOfCube(double a) {
		double result=0;
		int b=0;
		// TODO Auto-generated method stub
		do
		{
			b=(int)(a%10);
			a=a/10;
			result=result+Math.pow(b, 3);
		}while(a>0.9);
		return result;
	}
}
