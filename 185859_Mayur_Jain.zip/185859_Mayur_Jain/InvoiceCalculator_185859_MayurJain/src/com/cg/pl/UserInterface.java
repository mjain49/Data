package com.cg.pl;
import com.cg.bean.Invoice;
import com.cg.service.InvoiceServiceImpl;
import java.io.*;
import java.util.*;
public class UserInterface {

	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws IOException {
		InvoiceServiceImpl inSer=new InvoiceServiceImpl();
	while(true) 
	{
	  //For Displaying the Menu
	  System.out.println("\n********************Invoice Calculator Menu*******************");
	  System.out.println("1. Create New Invoice:");
	  System.out.println("2. Display All Invoices:");
	  System.out.println("3. Calculate Amount:");
	  System.out.println("4. Exit");
	  System.out.println("Enter your choice:");
	  int c=Integer.parseInt(br.readLine());
	switch(c) 
	{
	case 1:	//create Invoice
		int weight=valiadteInputWeight();
		int distance=validateInputDistance();
		Invoice ob=new Invoice(weight,distance);
		int res=inSer.saveInvoice(ob);
		if(res==1)
			System.out.println("Invoice Created");
		else
			System.out.println("Error");
		break;
	
	case 2: //Display All the Invoices
		Map<Integer,Invoice> map=new HashMap<>();
		map=inSer.getAllInvoices();
		Collection<Invoice> InvoiceValues=map.values();
		ArrayList<Invoice> InvoiceList=new ArrayList<>(InvoiceValues);
		System.out.println("*********************************************************");
		for(Invoice i:InvoiceList) 
		{
		System.out.println(i);
		System.out.println("*********************************************************");
		}
		break;
	case 3: //Calculate total amount for given weight and distance by user
  	
		int weight_cal=valiadteInputWeight();
		int distance_cal=validateInputDistance();
		double amount=inSer.calculateInvoice(new Invoice(weight_cal,distance_cal));
		System.out.println("Total Amount: "+amount);
		break;
	case 4: //Exit
		System.out.println("Exiting Program");
		System.exit(0);
	default: //For invalid choice
		System.out.println("Invalid choice");
  }
 }
 }
	
private static int validateInputDistance() throws IOException {
		 int distance=0;
		 while(true) {
		  try {
		  System.out.println("Enter Distance in KM: ");
		  distance=Integer.parseInt(br.readLine());
		  }
		  catch(NumberFormatException e)
		  {	
			  e.printStackTrace();
			  System.err.println(e.getMessage());
		  }
		  if(distance<100) {
		  return distance;
		  }
		  else if(distance <0){
		  System.out.println("Distance cannot be negative");
		  }
		  else 
			  System.out.println("Distance must be less than 100 KM");
		}
	}

private static int valiadteInputWeight() throws IOException {
	 int weight=0;
	 while(true) 
	 {
	  try {
	  System.out.println("Enter Weight in KG: ");
	  weight=Integer.parseInt(br.readLine());
	  }
	  catch(NumberFormatException e) {
	  e.printStackTrace();
	  System.err.println(e.getMessage());
	  }
	  if(weight>1) {
	  return weight;
	  }
	  else if(weight <0 ){
	  System.out.println("Weight cannot be negative");
	  }
	  else 
	  System.out.println("Weight must be greater than 1 KG");
	 }
	}
}

	
