package com.cg.dao;
import java.util.HashMap;
import java.util.Map;
import com.cg.bean.Invoice;
import com.cg.service.InvoiceServiceImpl;

public class InvoiceRepoImpl implements InvoiceRepo {
	 Map<Integer,Invoice> map=new HashMap<>();
	 @Override
	 public int saveInvoice(Invoice ob) 
	 {
	 map.put(ob.getId(),ob);
	 return 1;
	 }
	 
	 public Map<Integer,Invoice> getAllInvoices()
	 {
	 return map;
	 }

}