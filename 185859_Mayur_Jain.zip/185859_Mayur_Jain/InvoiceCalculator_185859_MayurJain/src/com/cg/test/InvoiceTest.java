package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;
import com.cg.bean.Invoice;
import com.cg.service.InvoiceServiceImpl;

class InvoiceTest {
 //Testing Methods
 InvoiceServiceImpl inSer;
 @BeforeEach
 void beforeEachTest() {
 inSer=new InvoiceServiceImpl();
 }

 @AfterEach
 void afterEachTest() {
 inSer=null;
 }
 
 @Test
 void testSaveInvoice() {
 Invoice ob=new Invoice(4,5);
 assertEquals(1,inSer.saveInvoice(ob));
 }
 
 @Test
 void testCalculateInvoice() 
 {
 Invoice ob=new Invoice(4,5);
 double transfer_charge=2*4*5;
 double gst=2*3.5*transfer_charge/100; //total tax i.e. sum of cgst and sgst
 double amt=transfer_charge+gst;
 assertEquals(amt,inSer.calculateInvoice(ob));
 }
}